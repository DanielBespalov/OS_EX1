#include <stdio.h>


int main()
{
    int a = 5;
    int b = a/0;
    return 0;
}